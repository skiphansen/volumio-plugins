'use strict';

const fs = require('fs');
const util = require('util');
const path = require('path');

const dir = '/mnt/USB/e884c5ea-1fda-4111-97ae-499ae0a90627/pandora_music/playlists'
const playlistdir = '/data/playlist/'


function import_m3u() {

    var dir = this.dir;
    var file = this.files[this.fileNdx];
    console.log('import_m3u: file "' + file + '"');
    var playlist_exists = false;
    var convert_playlist = true;
    var open_mode = 'w';
    var plist_ext = path.extname(file);
    var basename = path.basename(file,plist_ext);
    var playlist_path = playlistdir + basename;
    var results = 'Importing ' + file + ':<br>';

    switch(this.modalResult) {
    case 'no':
        this.fileNdx++;
        importPlaylists();
        return;

    case 'yes':
        break;

    case 'cancel':
        importPlaylists();
        return;

    default:
        break;
    }

    try {
        var stats = fs.lstatSync(playlist_path)
        playlist_exists = true;
    } catch (e) { }

    switch (this.option) {
        case "new":
            if(playlist_exists) {
                var msg = 'skipped, playlist already exists';
                console.log('  ' + msg);
                results += formatInfoResults(msg);
                convert_playlist = false;
            }
            break;

        case "all":
            break;

        case "ask":
            if(playlist_exists && this.modalResult == 'ask') {
                console.log('  Pop up modal here')
                return;
            }
    }

    if(convert_playlist) {
        var first = true;
        var url_next = false;
        var m3u_path = dir + '/' + file;
        var playlist_out = fs.openSync(playlist_path,'w')
        console.log('  processing '+ m3u_path)
        var data = fs.readFileSync(m3u_path).toString('utf8');
        if(data.includes('\n') && data.includes('\r')) {
            console.log('  file has carrage returns and line feeds');
        }
        else if(data.includes('\r')) { 
            console.log('  file has carrage returns');
            data.replace('\r','\n')
        }
        else if(data.includes('\n')) { 
            console.log('  file has line feeds');
        }
        else { 
            console.log('  file is empty ??? ');
        }
        var lines = data.split('\n');
        var extinf = '';
        var split_index = 0;
        var comma_index = 0;

        console.log('  contents (' + lines.length + ' lines):\n-----\n');
        for (let i = 0; i < lines.length; i++) {
            if(url_next) {
                var url_exists = false;
                var url = lines[i].trim().replace(/\\/g,'/')
                console.log('  url line: "' + url + '"');
                var url_path = path.normalize(dir + '/' + url);

                if(fs.existsSync(url_path)) {
                    console.log('  url exists: ' + url_path);
                    console.log('  extinf: ' + extinf);
                    var artist = extinf.substring(comma_index + 1,split_index).trim();
                    var title = extinf.substring(split_index + 3).trim();
                    console.log('  artist: "' + artist + '"');
                    console.log('  title: "' + title + '"');
                    if(first) {
                        first = false;
                        fs.writeSync(playlist_out,'[');
                    }
                    else {
                        fs.writeSync(playlist_out,',\n');
                    }

                    var entry = '{"service":"mpd",' +
                                '"uri":"' + url_path.substring(1) + 
                                '","title":"' + title + 
                                '","artist":"' + artist + '"}'

                    fs.writeSync(playlist_out,entry);
                }
                else {
                    var msg = "Couldn't find " + '"' + url_path + '"';
                    results += formatErrResults(msg);
                    console.log("  " + msg);
                }
                url_next = false;
            }
            else if(lines[i].startsWith('#EXTINF:')) {
                if((split_index = lines[i].indexOf(' - ')) > 0 && 
                   (comma_index = lines[i].indexOf(',')) > 0)
                {
                    extinf = lines[i].replace(/"/g,"\\\"");
                    url_next = true;
                }
                else {
                    var msg = 'parsing error: ' + lines[i];
                    results += formatErrResults(msg);
                    console.log('  ' + msg);
                }
            }
            else if(lines[i].startsWith('#')) {
                if(url_next) {
                    msg = 'parsing error, expected url: ' + lines[i];
                    results += formatErrResults(msg);
                    console.log('  ' + msg);
                }
            }
            else if(lines[i].trim().length != 0) {
                var msg = 'parsing error: ' + lines[i];
                results += formatErrResults(msg);
                console.log('  ' + msg);
            }
        }
        console.log('-----');
        fs.writeSync(playlist_out,']\n');
        fs.closeSync(playlist_out);
    }

    results += '<br>'
    return results;
}

function formatInfoResults(msg) {
    return msg + '<br>';
}

function formatErrResults(msg) {
    return msg + '<br>';
}




var stats = fs.lstatSync(dir);

console.log('stats: ' + util.inspect(stats));

if (stats.isDirectory()) {
    console.log('Path is a directory');
}
else {
    console.log('Path is NOT a directory');
    process.exit(1);
}

function importPlaylists() 
{
    console.log('this: ' + util.inspect(this));

    if (this.modalResult == 'cancel') {
        return;
    }
    this.modalResult = 'ask';

    for ( ; this.fileNdx < this.files.length; this.fileNdx++) {
        this.option = 'all';
        var file = this.files[this.fileNdx];
        var extension = path.extname(file).toLowerCase();
        switch (extension) {
            case '.m3u':
            case '.m3u8':
                this.import_m3u();
                break;

            default:
                console.log('File "' + file + '" ignored');
                break;
        }
    }
}

var importerInternal = {
	dir: '',
	modalResult: '',
	fileNdx: 0,
	files: {}
}

importerInternal.dir = dir;
importerInternal.files = fs.readdirSync(dir);
importerInternal.importPlaylists = importPlaylists.bind(importerInternal);
importerInternal.import_m3u = import_m3u.bind(importerInternal);


importerInternal.importPlaylists();

