set -x
cp -r . /data/plugins/miscellanea/m3u_importer/
volumio plugin refresh
volumio vrestart
